# PlayerX-RN Android SDK 集成指南



## Step0

在Android Studio工程的build.gradle文件中，加入我们的maven依赖，如下：

```groovy
allprojects {
    repositories {
        maven {
            url "https://xrepo.hujiang.com/repository/maven-public/"
        }
    }
}
```



## Step1

在App的主build.gradle加入ocsx的依赖以及相关的必须配置，如下：

```groovy
android {
    compileSdkVersion 29
    buildToolsVersion "30.0.1"

    defaultConfig {
       ...
       
        multiDexEnabled true

        ndk {
            abiFilters "armeabi", "armeabi-v7a"
        }
    }

    packagingOptions {
        exclude 'META-INF/DEPENDENCIES.txt'
        exclude 'META-INF/LICENSE.txt'
        exclude 'META-INF/NOTICE.txt'
        exclude 'META-INF/DEPENDENCIES'
        exclude 'META-INF/LICENSE'
        exclude 'META-INF/NOTICE'
    }

    lintOptions {
        abortOnError false
    }

    dexOptions {
        javaMaxHeapSize "2g"
        preDexLibraries = true
        jumboMode true
    }

}

dependencies {
	...
    implementation 'com.techedux.playerx:playerx-rn:1.0.13'
	...
}
```



## Step2

Application初始化

```java
public class MainApplication extends Application implements ReactApplication {

    private final ReactNativeHost mReactNativeHost =
            new ReactNativeHost(this) {
                @Override
                public boolean getUseDeveloperSupport() {
                    return BuildConfig.DEBUG;
                }

                @Override
                protected List<ReactPackage> getPackages() {
                    List<ReactPackage> packages = new PackageList(this).getPackages();
                    //添加VideoViewPackage
                    packages.add(new VideoViewPackage());
                    return packages;
                }

                @Override
                protected String getJSMainModuleName() {
                    return "index";
                }
            };

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        SoLoader.init(this, /* native exopackage */ false);
        initializeFlipper(this, getReactNativeHost().getReactInstanceManager());
        initOCS();
    }

    private void initOCS() {
        //ENV_ALPHA 测试环境 , ENV_BETA 验证环境 , ENV_RELEASE 正式环境
      	//setOpenSwitchLine 设置是否开启切换线路功能
      	//setSelectedWordOn 是否开启词典功能
        OCSRunTime.instance().init(this, HJEnvironment.ENV_ALPHA).setOpenSwitchLine(true);
        OCSRunTime.instance().getOCSPlayerConfig().setSelectedWordOn(false);
    }

    /**
     * Loads Flipper in React Native templates. Call this in the onCreate method with something like
     * initializeFlipper(this, getReactNativeHost().getReactInstanceManager());
     *
     * @param context
     * @param reactInstanceManager
     */
    private static void initializeFlipper(
            Context context, ReactInstanceManager reactInstanceManager) {
        if (BuildConfig.DEBUG) {
            try {
        /*
         We use reflection here to pick up the class that initializes Flipper,
        since Flipper library is not available in release mode
        */
                Class<?> aClass = Class.forName("com.hello.ReactNativeFlipper");
                aClass
                        .getMethod("initializeFlipper", Context.class, ReactInstanceManager.class)
                        .invoke(null, context, reactInstanceManager);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }
}
```



## Step3

在RN中使用

1.自定义OCSView组件

```js
import {findNodeHandle, requireNativeComponent, UIManager} from 'react-native';

import React from 'react';
const OCSView = requireNativeComponent('RNOCSPlayer');

export default class RNOCSView extends React.Component {
  _assignRoot = component => {
    this._root = component;
  };

  _dispatchCommand = (command, params = []) => {
    if (this._root) {
      UIManager.dispatchViewManagerCommand(
        findNodeHandle(this._root),
        command,
        params,
      );
    }
  };

  //开始播放
  startPlay = () => {
    this._dispatchCommand('startPlay');
  };
  //暂停播放
  pausePlay = () => {
    this._dispatchCommand('pausePlay');
  };
  //继续播放
  resumePlay = () => {
    this._dispatchCommand('resumePlay');
  };
  //释放
  destroyPlay = () => {
    this._dispatchCommand('destroyPlay');
  };
  //播放下一集
  playNext = params => {
    this._dispatchCommand('playNext', [params]);
  };
  //获取播放器信息
  getPlayerStatusInfo = () => {
    this._dispatchCommand('getPlayerStatusInfo');
  };
  //跳转指定播放时间
  seekTo = params => {
    this._dispatchCommand('seekTo', [params]);
  };
  render() {
    return <OCSView ref={this._assignRoot} {...this.props} />;
  }
}

```

2.使用OCS组件

```js
import React from 'react';
import {Button, Text, View} from 'react-native';
import RNOCSView from '../lib/RNOCSView';
import Orientation from 'react-native-orientation';

export default class VideoPage extends React.Component {
  constructor(props: P, context: any) {
    super(props, context);
    this.state = {
      progress: 0,
      duration: 0,
      realTime: 0,
      visible: 1,
      errorMessage: '',
      complete: '',
      height: '33%',
      ocsItemEntity: {
        CoursewareID: '1064794825521857528',
        Title: 'test',
        UserID: '78821',
        UserName: '4zik9t',
        TenantID: 'class_ocs',
        UserSign:
          'SfzkuWmr0s3vfpulHajOCK3T15qaw21rMAnjDYSLD0sO25kt9dZGSN06RGr4CNip3oMqRtzHeetMAOPzi0P4sBBHrZbeyWG0BW7mD/ax0LCjo5+r0B8XlLhgr4YnNHRIol08LtUG2iY8W85ZPImvD5ObMWK718oXSodmJjyA64ZTpEmbsa37JbMzV/7wJsyJ2eGZKgZUGBrlmIcQ+56KFykgFLln07ScwusScHa4YueV78923pUNMcs5wSjg23kdseT4boRykYiR4au3+j1jbJZcCGUhHP+Jm/gYCVm72lTuVIX3yb6Icicr2DEFAdRtroDQ1w7Vgbgsr8k/xIVyyg==',
        Env: 'pd',
        ProgressBackground: '#FD5A27',
        AutoPlay: true,
        FullscreenDisable: true,
      },
    };
  }

  componentDidMount() {
    Orientation.addOrientationListener(this._orientationDidChange);
  }

  _orientationDidChange = orientation => {
    console.log(orientation);
    if (orientation === 'LANDSCAPE') {
      this.setState({
        height: '100%',
      });
    } else {
      this.setState({
        height: '33%',
      });
    }
  };

  componentWillUnmount() {
    Orientation.removeOrientationListener(this._orientationDidChange);
    this._root.destroyPlay();
  }

  _assignRoot = component => {
    this._root = component;
  };

  render() {
    console.log('render');
    return (
      <View
        style={{
          width: '100%',
          height: '100%',
        }}>
        <RNOCSView
          ref={this._assignRoot}
          ocsItemEntity={this.state.ocsItemEntity}
          style={{
            background: '#000',
            width: '100%',
            height: this.state.height,
          }}
          onReady={({nativeEvent}) => {
            this._root.seekTo(0);
          }}
          onOCSError={({nativeEvent}) => {
            this.setState({
              errorMessage: nativeEvent.message,
            });
          }}
          onCompletion={({nativeEvent}) => {
            this.setState({
              complete: '播放完成',
            });
          }}
          onPlayerStatusInfo={({nativeEvent}) => {
            this.setState({
              progress: nativeEvent.currentProgress,
              duration: nativeEvent.duration,
              realTime: nativeEvent.realTime,
            });
          }}
          onVisibleCallBack={({nativeEvent}) => {
            this.setState({
              visible: nativeEvent.visible,
            });
          }}
        />
        <Button
          title={'播放'}
          onPress={() => {
            this._root.startPlay();
          }}
        />
        <Button
          title={'暂停'}
          onPress={() => {
            this._root.pausePlay();
          }}
        />
        <Button
          title={'继续'}
          onPress={() => {
            this._root.resumePlay();
          }}
        />
        <Button
          title={'释放'}
          onPress={() => {
            this._root.destroyPlay();
          }}
        />
        <Button
          title={'下一集'}
          onPress={() => {
            this._root.playNext({
              CoursewareID: '1069522061130142224',
              Title: 'test',
              UserID: '78821',
              UserName: '4zik9t',
              TenantID: 'class_ocs',
              UserSign:
                'DpbOWbLzzvXQN7tpgomDX0VYswzdxykqOLmNQRXIpZgfSAm0gAd3pUh66lczV4tw+FphB1Agprtg+W+sm4RLsw+5qbPjVAFHX1JsTsYDRreEqwlZ/WixMQkRKp3zwvYMAmV2l7WEbSqMT48euCpjHikjldbOuPEIfPZRSd9BXjxICgLQ8SKFDgZ0vneBoDMuWHwhwEJOcaxLJoOltpG0bMf5IiE8hjOSEG4Fc9mrjFfYRXT3dtZkIxOovEj+9H0yRpYTclSnJf8St2DESLRMgHCq6VCk3r+MUmmerTYBpWRLuI7rk7ol5C+NKwHdK5OF7RRpLVZMOWLF6uv1TqmBDQ==',
            });
          }}
        />
        <Button
          title={'获取播放器信息'}
          onPress={() => {
            this._root.getPlayerStatusInfo();
          }}
        />
        <Button
          title={'seek'}
          onPress={() => {
            this._root.seekTo(100);
          }}
        />
        <Text>
          {this.state.progress}/{this.state.duration}/{this.state.realTime}
        </Text>
        <Text>{this.state.errorMessage}</Text>
        <Text>{this.state.complete}</Text>
        <Text>{this.state.visible}</Text>
      </View>
    );
  }
}

```

## Step4

监听旋转屏幕事件

参考：

https://github.com/yamill/react-native-orientation





## Props

| name               | parmas                                                       | description                                     |
| ------------------ | ------------------------------------------------------------ | ----------------------------------------------- |
| onPlayerStatusInfo | currentProgress 当前进度(单位秒)<br />duration 总时长(单位秒)<br />realTime 用户学习时长(单位秒) | 获取播放进度回调，由getPlayerStatusInfo方法调用 |
| onOCSError         | errorCode 错误码<br />message 错误信息                       | 错误回调                                        |
| onCompletion       | durationInMills播放结束时间(单位秒)<br />                    | 播放完成回调                                    |
| ocsItemEntity      | CoursewareID: '课程id'，必传<br/>Title: '课程名称'，必传<br/>UserID: '用户ID'，必传<br/>UserName: '用户名称'，必传<br/>TenantID: '租户id'，必传<br/>UserSign: '用户签名'，必传<br />Env: 'qa,yz,pd'，‘环境切换’，非必传<br />AutoPlay:true/false ，是否需要自动播放，非必传,默认自动播放<br />FullscreenDisable: true/false，是否隐藏竖屏状态下的全屏按钮，默认为false 显示全屏按钮，非必传 |                                                 |
| onReady            |                                                              | 准备播放回调                                    |
| onVisibleCallBack  | visible : 0-隐藏，1-显示                                     | 播放控制器的隐藏和显示回调                      |



## Method

| name                | parmas                                                       | description                                      |
| ------------------- | ------------------------------------------------------------ | ------------------------------------------------ |
| startPlay           |                                                              | 开始播放                                         |
| pausePlay           |                                                              | 暂停播放                                         |
| resumePlay          |                                                              | 继续播放                                         |
| destroyPlay         |                                                              | 释放                                             |
| playNext            | CoursewareID: '课程id',必传<br/>Title: '课程名称',必传<br/>UserID: '用户ID',必传<br/>UserName: '用户名称',必传<br/>TenantID: '租户id',必传<br/>UserSign: '用户签名',必传 | 播放下一集                                       |
| getPlayerStatusInfo |                                                              | 获取播放器进度信息，回调方法onPlayerStatusInfo： |
| seekTo              | 参数为第一个位置，整型                                       | 跳转到指定播放位置（秒）                         |



## 错误码

| code | message            |
| ---- | ------------------ |
| 1    | 网络连接异常       |
| 2    | 播放器异常         |
| 3    | 未知错误           |
| 4    | 数据源异常         |
| 5    | 缓冲超时           |
| 6    | 连接超时           |
| 7    | 通信异常           |
| 8    | 数据解析异常       |
| 9    | 播放器不支持       |
| 10   | 身份验证出错       |
| 11   | 取消播放           |
| 12   | 参数为空           |
| 13   | 课件内容变更       |
| 14   | 用户播放权限已过期 |

