# PlayerX Android SDK 原生集成指南



## Step0

在Android Studio工程的build.gradle文件中，加入我们的maven依赖，如下：

```groovy
allprojects {
    repositories {
        maven {
            url "https://xrepo.hujiang.com/repository/maven-public/"
        }
    }
}
```



## Step1

在App的主build.gradle加入ocsx的依赖以及相关的必须配置，如下：

```groovy
android {
    compileSdkVersion 30
    buildToolsVersion "30.0.1"

    defaultConfig {
       ...
        targetSdkVersion 30
        multiDexEnabled true

        ndk {
            abiFilters "armeabi-v7a",'arm64-v8a'
        }
    }

    packagingOptions {
        exclude 'META-INF/DEPENDENCIES.txt'
        exclude 'META-INF/LICENSE.txt'
        exclude 'META-INF/NOTICE.txt'
        exclude 'META-INF/DEPENDENCIES'
        exclude 'META-INF/LICENSE'
        exclude 'META-INF/NOTICE'
    }

    lintOptions {
        abortOnError false
    }

    dexOptions {
        javaMaxHeapSize "2g"
        preDexLibraries = true
        jumboMode true
    }

}

dependencies {
	...
    //播放器中需要用到
    implementation 'junit:junit:4.13.2'
    //播放器
    implementation 'com.techedux.ocs:ocsx-androidx:1.1.7.3-SNAPSHOT'
	...
}
```

## Step2

AndroidManifest配置

权限配置

```xml
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" />
<uses-feature android:name="android.hardware.camera.autofocus" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

使用 `targetSdkLevel >= 30` ，在application节点需要配置

```xml
android:allowNativeHeapPointerTagging="false"
```





## Step3

Application初始化

```java
public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //初始化
        OCSRunTime.instance().init(this, HJEnvironment.ENV_RELEASE);
        //开启切换线路
        OCSRunTime.instance().setOpenSwitchLine(true);
    }
}
```



## Step4

启用播放

```java
OCSItemEntity itemEntity =new OCSItemEntity();
itemEntity.mIsOnline = true;
itemEntity.mXTenantID = "class_ocs";
itemEntity.mVersion = "5";
itemEntity.mUserID = "78821";
itemEntity.mLessonName = "test";
itemEntity.mLessonID = 1064794825521857528L;
itemEntity.mXUserSign = "SfzkuWmr0s3vfpulHajOCK3T15qaw21rMAnjDYSLD0sO25kt9dZGSN06RGr4CNip3oMqRtzHeetMAOPzi0P4sBBHrZbeyWG0BW7mD/ax0LCjo5+r0B8XlLhgr4YnNHRIol08LtUG2iY8W85ZPImvD5ObMWK718oXSodmJjyA64ZTpEmbsa37JbMzV/7wJsyJ2eGZKgZUGBrlmIcQ+56KFykgFLln07ScwusScHa4YueV78923pUNMcs5wSjg23kdseT4boRykYiR4au3+j1jbJZcCGUhHP+Jm/gYCVm72lTuVIX3yb6Icicr2DEFAdRtroDQ1w7Vgbgsr8k/xIVyyg==";
OCSPlayer.instance().play(itemEntity, null);
```

