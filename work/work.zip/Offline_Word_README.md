# Offline Word 

## Android编译文档说明

**分支:jpFind**



### 部分目录介绍

android ：Android 运行Demo

native : 离线词库项目

​	compiler：离线词库编译库，主要用来生成离线词库的.so文件

​	static : sqlite ,crypto 静态库



### 编译说明

我的环境是win10编译的，所以未用到compiler项目。

compiler项目作用:生成debug.inc头文件，生成compiler可执行文件，通过生成的可执行文件用命令去编译，但是生成的可执行文件只支持linux环境，不支持win环境



### win10(64位)环境编译

codetyphon版本是7.5(目前最新的是7.5)



#### 1.下载安装codetyphon

https://www.pilotlogic.com/sitejoom/index.php/downloads.html

#### 2.安装完成后下载工具链和操作系统

参考链接:

https://www.pilotlogic.com/sitejoom/index.php/93-wiki/ct-tutorials/222-cross-build-for-android

##### toolchains:

win64-aarch64-android

win64-arm-android

win64-i386-android

##### 操作系统:

android-8.0.x-api26-aarch64

android-8.0.x-api26-arm

android-8.0.x-api26-i386



注意：

如果toolchains在安装软件时，已经安装好这些toolchains的情况下，建议最好在重新下载，防止部分编译工具没下载全。



#### 3.构建FPC

操作路径：CrossBuild - FreePascal 64bits 

Cross element  for aarch64-android

Cross element  for arm-android

Cross element  for i386-android





#### 4.安装编译器(应该可以省略)

安装BigIDE

操作路径：Typhon-IDE - Typhon64 IDE,Build BigIDE



不建议安装SmallIDE



#### 5.创建debug.inc

```
{.$DEFINE DEBUG}
{$UNDEF STRDATA}
{$IFDEF DEBUG}
  {$DEFINE STRDATA}
{$ENDIF}
{$IFNDEF DEBUG}
  {$DEFINE ANDROID}
  {.$DEFINE IOS}
{$ENDIF}
{$IFDEF IOS}
{$ENDIF}
{$IFDEF ANDROID}
  {$DEFINE STRDATA}
  {$DEFINE ANDROID_AARCH64}
{$ENDIF}
{$IFNDEF ANDROID}
  {$DEFINE LOAD_DYNAMICALLY}
{$ENDIF}
{$IFDEF DEBUG}
  {$DEFINE PERFOEMANCE_TEST}
{$ELSE}
  {$UNDEF PERFOEMANCE_TEST}
{$ENDIF}
```

宏变量描述:

arm64位:

{$DEFINE ANDROID_AARCH64}

arm32位:

{$DEFINE ANDROID_ARM}

X86:

{$DEFINE ANDROID_X86}



需要编译哪个平台的so就修改哪个



#### 6.编译

```
linux to arm:
/usr/local/codetyphon/fpc/fpc64/bin/x86_64-linux/fpc -B -Tandroid -Parm -MobjFPC -Scghi -O3 -vewnhibq -Fl/usr/local/codetyphon/binLibraries/android-8.0.x-api26-arm -Fisqlite -Fi. -Fusqlite -Fudb -Fuutf -Fuplugin -Fuos -Fucompress -Fu. -olibofflineword_arm.so offlineword.lpr

linux to x86:
/usr/local/codetyphon/fpc/fpc64/bin/x86_64-linux/fpc -B -Tandroid -Pi386 -MObjFPC -Scghi -O3 -vewnhibq -Fl/usr/local/codetyphon/binLibraries/android-8.0.x-api26-i386 -Fisqlite -Fi. -Fusqlite -Fudb -Fuutf -Fuplugin -Fuos -Fucompress -Fu. -olibofflineword_x86.so offlineword.lpr

linux to aarc64:
/usr/local/codetyphon/fpc/fpc64/bin/x86_64-linux/fpc -B -Tandroid -Paarch64 -MobjFPC -Scghi -O3 -vewnhibq -Fl/usr/local/codetyphon/binLibraries/android-8.0.x-api26-aarch64 -Fisqlite -Fi. -Fusqlite -Fudb -Fuutf -Fuplugin -Fuos -Fucompress -Fu. -olibofflineword_aarc64.so offlineword.lpr

windows to aarc64
C:\codetyphon\fpc\fpc64\bin\x86_64-win64\fpc -B -Tandroid -Paarch64 -MobjFPC -Scghi -O3 -vewnhibq -FlC:\codetyphon\binLibraries\android-8.0.x-api26-aarch64 -Fisqlite -Fi. -Fusqlite -Fudb -Fuutf -Fuplugin -Fuos -Fucompress -Fu. -olibofflineword_aarc64.so offlineword.lpr
```

编译命令目录需修改为对应的电脑安装下的fpc目录





#### 其他参考:

1.使用 Arm Compiler 6 构建对 AArch64 状态的 128 位浮点（长双）支持

如果需要修改/native/static/sqlite-android里的源码，在编译64位的时候需要注意以下问题。

因为 AArch64 状态仅支持硬件浮点指令，而 Arm 架构不支持 128 位浮点指令

https://developer.arm.com/documentation/ka004751/1-0?lang=en&rev=3

操作步骤：

将44个文件下载下来，创建andorid cmake项目，再将sqlite3.c和sqlite3.h文件拷贝到一起，编译出libsqlite3_aarch64_android.a静态库

```cmake
cmake_minimum_required(VERSION 3.10.2)

project("longdoubleapp")
file(GLOB allCPP *.c *.h *.inc)

add_library(
        static-lib
        STATIC
        ${allCPP}
)

target_link_libraries(
        static-lib
)
```







### linux环境编译(不推荐，compiler脚本暂不支持64位)

下载安装步骤(1-4步骤)省略。。。

#### 1.编译compiler可执行文件

用codetyphon IDE打开compiler.ctpr项目,进行编译

#### 2.执行脚本命令

```
$ # 此命令表示，编译 Android 平台的库，查词模块版本为 200
$ ./compiler -p android -v 200
```













## 以下为旧版文档,可以参考



- - -

**native sqlite 的部分，除了何晓杰外，其他人严禁修改！**

**native sqlite 的部分，除了何晓杰外，其他人严禁修改！**

**native sqlite 的部分，除了何晓杰外，其他人严禁修改！**

**重要的事说三遍！**

- - -

**架构图**

![](https://gitlab.yeshj.com/android_libraries/offline_word/raw/master/arch_offlineword.png)

- - -

**WordData 数据结构**

|Field|Type|Extern OC|Extern Java|Desc|
|:--|:--|:--|:--|:--|
|_ID|Int64|long long|long|词条id|
|Word|string|char\*|String|词条名称|
|Explan|string|char\*|String|简明释义|
|Content|string|char\*|String|完整内容, 原json字符串|
|WordExt|string|char\*|String|附加的词条内容，原 wordex|
|Kana|string|char\*|String|假名|
|IPA|string|char\*|String|音标|
|FreqCommon|Int64|long long|long|通用词频|
|FreqRelative|Int64|long long|long|相对词频(官方词频调整)|
|FreqUser|Int64|long long|long|用户词频(根据用户个人查词习惯调整)
|DictId|Integer|int|int|来源词库id|
|Version|Integer|int|int|词条版本(更新词条时会更改版本号)|
|Status|Integer|int|int|词条状态(默认0，已删除1, 已隐藏2)|
|Data1|string|char\*|String|附加字段，暂无意义，占坑用|
|Data2|string|char\*|String| |
|Data3|string|char\*|String| |
|Data4|string|char\*|String| |
|Data5|string|char\*|String| |

- - -

**WordData数据结构映射**

```
type
  TWordData = packed record
    _ID: Int64;
    Word: (PChar/string);
    Explan: (PChar/string);
    WordExt: (PChar/string);
    Content: (PChar/string);
    Kana: (PChar/string);
    IPA: (PChar/string);
    Data1: (PChar/string);
    Data2: (PChar/string);
    Data3: (PChar/string);
    Data4: (PChar/string);
    Data5: (PChar/string);
    FreqCommon: Int64;
    FreqRelative: Int64;
    FreqUser: Int64;
    DictId: Integer;
    Version: Integer;
    Status: Integer;
  end;
```

出于跨平台数据对齐从 (ID，不定长段，定长段) 的原则，进行 record 数据编排，该编排格式若需要修改请联系何晓杰

- - -

**解压字典文件**

**bool decodeUnzip(string APath, string ASavePath)**

> APath: 经过压缩的字典文件路径
> 
> ASavePath: 解压后的字典文件保存位置（后续操作的字典路径，使用解压后的路径）
> 
> return: 是否解压成功
> 
> memo: 若是没有使用压缩，则不需要使用此方法，调用此方法前，必须先调用 ```setCompressParams``` 对压缩参数进行设置

- - -

**获取查词模块版本号**

**int getVersion()**

> return: 当前的查词模块版本号

- - -

**设置查词模块参数**

**void setOfflineWordParams(bool ACombine, bool ASortOrigin, bool ASortFreq, bool AReplace, bool AResort, int AUserFreqWeights)**

> ACombine: 是否联结搜索，即英文后带中文混搜
>
> ASortOrigin: 是否原始排序，该选项优先级高于 ASortFreq
> 
> ASortFreq: 是否按词频排序，选否的情况按单词在数据库内的顺序进行排序
>
> AReplace: 是否在查词前进行假名替换（仅对日语有效）
>
> AResort: 是否在查询后还要对结果重新排序（仅对日语有效）
>
> AUserFreqWeights: 用户词频的权重，在运算时以库内保存的用户词频乘以权重

- - -

**设置词典文件压缩参数**

**void setCompressParams(bool ACompress, int ACompressMethod)**

> ACompress: 是否启用压缩
>
> ACompressMethod: 压缩方式（0: hjz, 压缩率高，解压慢；1:zip，压缩率低，解压快）
>
> memo: 默认启用压缩，压缩方式为0

- - -

**设置批量增加或更新数据时的一次处理数量**

**void setDataBatchSize(int Asize)**

> ASize: 一次处理数量，默认值为5000
>
> memo: 执行 ```appendDict``` 和 ```updateDict``` 之前可以执行此方法

- - -

**获取词典文件是否被压缩**

**bool getCompressStatus(string APath)**

> APath: 词典文件的路径
>
> return: 是否压缩

- - -

**获取词典文件的压缩方式**

**int getCompressMethod(string APath)**

> APath: 词典文件的路径
>
> return: 压缩方式(-1: 未压缩，0:hjz，1:zip)

- - -

**获取词典文件的完整性**

**bool getDictCorrection(string APath)**

> APath: 词典文件的路径（解压后的词典）
>
> return: 是否完整

- - -

**最小化词典文件**

**bool minimize(string APath)**

> APath: 词典文件的路径（解压后的词典）
>
> return: 是否最小化成功
>
> memo: 这个操作必须在线程里进行，并且必须锁定数据库，即不能有任何其他操作发生，否则会损坏数据库

- - -

**查询一个特定的、完全匹配的单词**

**bool getWordDetail(string APath, string AKeyword)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AKeyword: 要搜索的关键字，此处必须是完整的单词
> 
> return: 是否查询成功

- - -

**查询建议的单词**

**bool searchSuggests(string APath, string AKeyword, int ACount)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AKeyword: 要搜索的关键字，查询结果以此关键字为开头
> 
> ACount: 要返回的结果条目数
> 
> return: 是否查询成功

- - -

**英语查词联想**

**WordData *searchEn(string APath, string AKeyword, int ACount, bool AFull)** ```Common```

**WordData *searchEnSuggestList(string APath, string AKeyword, int ACount, bool AFull);** ```Android```

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AKeyword: 要搜索的关键字，查询结果以此关键字为开头
> 
> ACount: 要返回的结果条目数
> 
> AFull: 是否返回全部字段，出于性能考虑，查询联想词时，AFull 设为 False
>
> return: 有序结果列表

- - -

**日语查词联想**

**WordData *searchJp(string APath, string AKeyword, int ACount, bool AFull)** ```Common```

**WordData *searchJpSuggestList(string APath, string AKeyword, int ACount, bool AFull);** ```Android```

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AKeyword: 要搜索的关键字，查询结果以此关键字为开头
> 
> ACount: 要返回的结果条目数
> 
> AFull: 是否返回全部字段，出于性能考虑，查询联想词时，AFull 设为 False
>
> return: 有序结果列表

- - -

**获取已查询到的条目数**

**int getResultCount(string APath)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> return: 该词典已被查询到的单词条目数
> 
> memo: 仅当调用 ```getWordDetail``` 或 ```searchSuggests``` 成功时可以调用

- - -

**获取已查询到的具体词条**

**WordData getResultItem(string APath, int AIndex, bool AFull)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AIndex: 词条在结果集合中的位置
>
> AFull: 是否返回全部字段，出于性能考虑，查询联想词时，AFull 设为 False
>
> return: 指定位置的词条数据
> 
> memo: 仅当调用 ```getWordDetail``` 或 ```searchSuggests``` 成功时可以调用

- - -

**释放查询结果的具体词条**

**void freeResultItem(WordData e, bool AFull)**

> e: 要被释放的结果词条
>
> AFull: 是否完整的数据集，此处的值与 getResultItem 所传入的一致
>
> memo: 仅针对在非 STRDATA 情况下，执行过 getResultItem 需要进行的释放动作, 目前 android 和 单元测试 的程序不需要执行此方法

- - -

**更新用户词频**

**bool updateUserFreq(string APath, long AWordId, long AFreq)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> AWordId: 词条id
> 
> AFreq: 用户词频的增量，以+1/-1等形式体现
> 
> memo: 若增量计算后，词频小于0，则计为0，原则上用户词频只增不减

- - -

**合并额外的词典**

**bool mergeDict(string APath, string ANewPath)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
> 
> ANewPath: 要合并的词典路径
> 
> return: 是否合并成功
> 
> memo: 传入的词典文件路径必须是解密后的文件

- - -

**删除额外的词典**

**bool removeDict(string APath, int ADictId)**

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
>
> ADictId: 要删除的词典id
> 
> return: 是否删除成功
>
> memo: 不能删除 id 为 0 的词典

- - -

**获取最后的一个异常**

**string getLastError()**

> return: 最后产生的异常信息
> 
> memo: 应当在任何操作返回 false 时，都立即通过此函数获取异常信息

- - -

**对日语按照发音额外排序**

**void resortKana(struct WordData\* AArr)** ```Common```

**void resortKatakana(struct WordData\* AArr, int ALen, bool AFull)** ```Android```

> AArr: 要被排序的数组，该数组来源于查词结果
>
> ALen: 数组长度
>
> AFull: 是否完整数据集

- - -

**对英文查询结果进行额外排序**

**void  resortEn(struct WordData\* AArr, string AKeyword)** ```Common```

**void resortWord(struct WordData\* AArr, string AKeyword, int ALen, bool AFull)** ```Android```

> AArr: 要被排序的数组，该数组来源于查词结果
>
> ALen: 数组长度
>
> AKeyword: 查询输入
>
> AFull: 是否完整数据集

- - -
**对日文查询结果进行额外排序**

**void  resortJP(struct WordData\* AArr, string AKeyword, int isFromExt)** ```Common```

**void resortJPWord(struct WordData\* AArr, string AKeyword, int ALen, int isFromExt, bool AFull)** ```Android```

> AArr: 要被排序的数组，该数组来源于查词结果
>
> ALen: 数组长度
>
> AKeyword: 查询输入
>
> isFromExt: 联想字段(1: word_ext，-1: word)
>
> AFull: 是否完整数据集

- - -

**对数据库文件进行强制替换**

**bool forceReplaceDict(string APath, string ANewPath)**

> APath: 词典的路径
>
> ANewPath: 用于替换的词典的路径
>
> return: 是否替换成功
>
> memo: 具体步骤为：删掉APath所指的文件，将ANewPath所指的文件移动至APath

- - -

**导出用户词频**

**bool exportUserFreq(string APath, string ASaveFilePath)**

> APath: 词典的路径
>
> ASaveFilePath: 要保存到的词频文件的路径（词频文件是名值对文本文件）
>
> return: 是否导出成功

- - -

**导入用户词频**

**bool importUserFreq(string APath, String AFreqFilePath)**

> APath: 词典的路径
>
> AFreqFilePath: 词频文件的路径（必须是exportUserFreq所导出的格式）
>
> return: 是否导入成功

- - -

**查询条件分词**

**string splitToString(string AStr)**

> AStr: 要被分词的字符串
>
> return: 分词结果，以逗号隔开

- - -

**释放查询分词结果**

**void freeSplitString(string AStr)**

> AStr: 要被释放的字符串
>
> memo: 仅针对在非 STRDATA 情况下，执行过 splitToString 需要进行的释放动作, 目前 android 和 单元测试 的程序不需要执行此方法

- - -

**增加分词分隔符**

**void addSplitChar(char AChar)**

> AChar: 要增加的分隔符
>
> memo: 默认分符隔为 空格，逗号，分号，竖线，正斜线

- - -

**删除分词分隔符**

**void removeSplitChar(char AChar)**

> AChar: 要删除的分隔符
>
> memo: 默认分符隔为 空格，逗号，分号，竖线，正斜线

- - -

**判断一个字符串是否以中文开头**

**bool isStartWithChinese(string AStr)**

> AStr: 要进行判断的字符串
>
> return: 是否以中文开头
>
> memo: 为了判断正确，必须传入UTF8字符串

- - -

 **插入一个词到词库**

**bool insertWord(string APath, struct WordData newWord)** ```Common```

**bool insertWord(String APath, WordData newWord, bool AFull)** ```Android```

> APath: 词典的路径（必须以 dict\_\<from\>\_\<to\>_ 形式命名）
>
> newWord: 要插入的新词
>  
> AFull: 是否完整数据集
>
> return: 是否成功
>
> memo: 新词的id字段由底层填充

- - -

**编译方案**

新查词模块拥有自己的编译方案，在编译模块时，需要注意编译工具以及编译环境，使用自定义编译命令：

```
$ # 此命令表示，编译 Android 平台的库，查词模块版本为 200
$ ./compiler -p android -v 200
```

若是要编译其他平台，可以使用指定的平台名称来进行，下表说明了编译的平台以及产物：

|Host|Dest Platform|Output|Bit|
|:---|:---|:---|:---|
| Linux | linux | libofflineword.so | 64 |
| | android | libofflineword_arm.so | 32 |
| | | libofflineword\_x86.so | 32 |
| Mac OSX | mac | libofflineword\_32.dylib | 32 |
| | | libofflineword\_64.dylib | 64 |
| | ios | libofflineword.a | AArch64, Armv7, x86\_64, x86 |
| Windows | windows | offlineword\_32.dll | 32 |
| | | offlineword\_64.dll | 64 |

编译工具的架构图如下所示：

![](https://gitlab.yeshj.com/android_libraries/offline_word/raw/master/arch_compiler.png)

- - -

**词典文件生成工具**

可以使用全新的词典生成工具来进行词典的生成。生成词典前，必须拥有原始数据库文件。

```
$ ./dictmakerx
    --comp,    -c    是否进行压缩和加密
    --freq,    -f    词频文件所在路径
    --dictid,  -d    词典ID
    --version, -n    词典内单词的版本号
    --no-content     不输出 content 内容
    --slice,   -s    是否做数据库切片
    --input,   -i    输入的原始词典文件
    --output,  -o    输出的新版本词典文件
    --verbose, -v    是否打印Verbose信息
```

样例命令如下：

```
$ ./dictmakerx -c -v -freq ./filesx -d 2 -n 3 -s 10000 -i ./filesx/en_ec_format.db -o dict_en_cn_1.0.db
```

词典生成工具的架构图如下所示：

![](https://gitlab.yeshj.com/android_libraries/offline_word/raw/master/arch_dictmaker.png)

- - -

**增量词库合并**

合并前提：增量词库中没有相同数据

```
$ ./mergedb 
    { DATABASE_PATH } 输入参数为增量数据库路径
```

样例命令如下：

```
$ ./mergedb ./input
```
增量数据库合并的架构图如下所示：

![](https://gitlab.yeshj.com/android_libraries/offline_word/raw/mergedb/arch_mergedb.png)

=======

